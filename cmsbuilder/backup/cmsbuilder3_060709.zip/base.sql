-- MySQL dump 10.9
--
-- Host: localhost    Database: cmsbuilder3
-- ------------------------------------------------------
-- Server version	4.1.16-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access`
--

DROP TABLE IF EXISTS `access`;
CREATE TABLE `access` (
  `ID` int(11) NOT NULL auto_increment,
  `url` varchar(50) NOT NULL default '',
  `memb` varchar(50) NOT NULL default '',
  `code` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `memb` (`memb`),
  KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `access`
--


/*!40000 ALTER TABLE `access` DISABLE KEYS */;
LOCK TABLES `access` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `access` ENABLE KEYS */;

--
-- Table structure for table `arr_modAdmin-modRoot1`
--

DROP TABLE IF EXISTS `arr_modAdmin-modRoot1`;
CREATE TABLE `arr_modAdmin-modRoot1` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modAdmin-modRoot1`
--


/*!40000 ALTER TABLE `arr_modAdmin-modRoot1` DISABLE KEYS */;
LOCK TABLES `arr_modAdmin-modRoot1` WRITE;
INSERT INTO `arr_modAdmin-modRoot1` VALUES (1,1,'modSite::modSite','0000-00-00 00:00:00','0000-00-00 00:00:00',''),(2,1,'modTemplates::modTemplates','0000-00-00 00:00:00','0000-00-00 00:00:00',''),(3,1,'modUsers::modUsers','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modAdmin-modRoot1` ENABLE KEYS */;

--
-- Table structure for table `arr_modTemplates-Dir1`
--

DROP TABLE IF EXISTS `arr_modTemplates-Dir1`;
CREATE TABLE `arr_modTemplates-Dir1` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modTemplates-Dir1`
--


/*!40000 ALTER TABLE `arr_modTemplates-Dir1` DISABLE KEYS */;
LOCK TABLES `arr_modTemplates-Dir1` WRITE;
INSERT INTO `arr_modTemplates-Dir1` VALUES (1,1,'modTemplates::Template','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modTemplates-Dir1` ENABLE KEYS */;

--
-- Table structure for table `arr_modTemplates-modTemplates1`
--

DROP TABLE IF EXISTS `arr_modTemplates-modTemplates1`;
CREATE TABLE `arr_modTemplates-modTemplates1` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modTemplates-modTemplates1`
--


/*!40000 ALTER TABLE `arr_modTemplates-modTemplates1` DISABLE KEYS */;
LOCK TABLES `arr_modTemplates-modTemplates1` WRITE;
INSERT INTO `arr_modTemplates-modTemplates1` VALUES (1,1,'modTemplates::Dir','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modTemplates-modTemplates1` ENABLE KEYS */;

--
-- Table structure for table `arr_modUsers-Group1`
--

DROP TABLE IF EXISTS `arr_modUsers-Group1`;
CREATE TABLE `arr_modUsers-Group1` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modUsers-Group1`
--


/*!40000 ALTER TABLE `arr_modUsers-Group1` DISABLE KEYS */;
LOCK TABLES `arr_modUsers-Group1` WRITE;
INSERT INTO `arr_modUsers-Group1` VALUES (1,1,'modUsers::User','0000-00-00 00:00:00','0000-00-00 00:00:00',''),(2,2,'modUsers::User','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modUsers-Group1` ENABLE KEYS */;

--
-- Table structure for table `arr_modUsers-Group2`
--

DROP TABLE IF EXISTS `arr_modUsers-Group2`;
CREATE TABLE `arr_modUsers-Group2` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modUsers-Group2`
--


/*!40000 ALTER TABLE `arr_modUsers-Group2` DISABLE KEYS */;
LOCK TABLES `arr_modUsers-Group2` WRITE;
INSERT INTO `arr_modUsers-Group2` VALUES (1,3,'modUsers::User','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modUsers-Group2` ENABLE KEYS */;

--
-- Table structure for table `arr_modUsers-modUsers1`
--

DROP TABLE IF EXISTS `arr_modUsers-modUsers1`;
CREATE TABLE `arr_modUsers-modUsers1` (
  `num` int(11) NOT NULL auto_increment,
  `ID` int(11) NOT NULL default '-1',
  `CLASS` char(40) NOT NULL default '',
  `ATS` datetime NOT NULL default '0000-00-00 00:00:00',
  `CTS` datetime NOT NULL default '0000-00-00 00:00:00',
  `NAME` char(10) NOT NULL default '',
  KEY `num` (`num`),
  KEY `ID` (`ID`),
  KEY `CLASS` (`CLASS`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `arr_modUsers-modUsers1`
--


/*!40000 ALTER TABLE `arr_modUsers-modUsers1` DISABLE KEYS */;
LOCK TABLES `arr_modUsers-modUsers1` WRITE;
INSERT INTO `arr_modUsers-modUsers1` VALUES (1,1,'modUsers::Group','0000-00-00 00:00:00','0000-00-00 00:00:00',''),(2,2,'modUsers::Group','0000-00-00 00:00:00','0000-00-00 00:00:00','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `arr_modUsers-modUsers1` ENABLE KEYS */;

--
-- Table structure for table `dbo_VTypes-Test`
--

DROP TABLE IF EXISTS `dbo_VTypes-Test`;
CREATE TABLE `dbo_VTypes-Test` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `object` int(11) NOT NULL default '0',
  `checkbox` int(1) NOT NULL default '0',
  `int` int(11) NOT NULL default '0',
  `time` time NOT NULL default '00:00:00',
  `date` date NOT NULL default '0000-00-00',
  `file` varchar(50) NOT NULL default '',
  `string` varchar(255) NOT NULL default '',
  `string2` varchar(10) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `timestamp` timestamp NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `miniword` text NOT NULL,
  `select` enum('1','2','3') NOT NULL default '1',
  `ObjectsList2` int(11) NOT NULL default '0',
  `password1` varchar(32) NOT NULL default '',
  `bool` int(1) NOT NULL default '0',
  `ObjectsList` int(11) NOT NULL default '0',
  `radio` enum('1','2','3') NOT NULL default '1',
  `ObjectsList1` int(11) NOT NULL default '0',
  `string1` text NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_VTypes-Test`
--


/*!40000 ALTER TABLE `dbo_VTypes-Test` DISABLE KEYS */;
LOCK TABLES `dbo_VTypes-Test` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_VTypes-Test` ENABLE KEYS */;

--
-- Table structure for table `dbo_modAdmin-modRoot`
--

DROP TABLE IF EXISTS `dbo_modAdmin-modRoot`;
CREATE TABLE `dbo_modAdmin-modRoot` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` char(50) NOT NULL default '0',
  `PAPA_CLASS` char(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `onpage` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modAdmin-modRoot`
--


/*!40000 ALTER TABLE `dbo_modAdmin-modRoot` DISABLE KEYS */;
LOCK TABLES `dbo_modAdmin-modRoot` WRITE;
INSERT INTO `dbo_modAdmin-modRoot` VALUES ('2006-07-08 11:45:22','2006-07-08 11:45:22',1,'modUsers::UsermodUsers::User1','modControlPanel::ControlPanel',1,0,0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modAdmin-modRoot` ENABLE KEYS */;

--
-- Table structure for table `dbo_modNews-News`
--

DROP TABLE IF EXISTS `dbo_modNews-News`;
CREATE TABLE `dbo_modNews-News` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `content` text NOT NULL,
  `name` varchar(100) NOT NULL default '',
  `ndate` date NOT NULL default '0000-00-00',
  `title` varchar(255) NOT NULL default '',
  `hidden` int(1) NOT NULL default '0',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modNews-News`
--


/*!40000 ALTER TABLE `dbo_modNews-News` DISABLE KEYS */;
LOCK TABLES `dbo_modNews-News` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modNews-News` ENABLE KEYS */;

--
-- Table structure for table `dbo_modNews-modNews`
--

DROP TABLE IF EXISTS `dbo_modNews-modNews`;
CREATE TABLE `dbo_modNews-modNews` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `hidden` int(1) NOT NULL default '0',
  `onpage` int(11) NOT NULL default '0',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modNews-modNews`
--


/*!40000 ALTER TABLE `dbo_modNews-modNews` DISABLE KEYS */;
LOCK TABLES `dbo_modNews-modNews` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modNews-modNews` ENABLE KEYS */;

--
-- Table structure for table `dbo_modRegistration-Client`
--

DROP TABLE IF EXISTS `dbo_modRegistration-Client`;
CREATE TABLE `dbo_modRegistration-Client` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `bdate` varchar(255) NOT NULL default '',
  `orders` varchar(50) NOT NULL default '',
  `street` varchar(255) NOT NULL default '',
  `remind` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `city` varchar(255) NOT NULL default '',
  `tel` varchar(255) NOT NULL default '',
  `fax` varchar(255) NOT NULL default '',
  `country` varchar(255) NOT NULL default '',
  `email2` varchar(255) NOT NULL default '',
  `second` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `sex` enum('none','male','female') NOT NULL default 'none',
  `login` varchar(255) NOT NULL default '',
  `zip` varchar(255) NOT NULL default '',
  `building` varchar(255) NOT NULL default '',
  `fam` varchar(255) NOT NULL default '',
  `pas` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modRegistration-Client`
--


/*!40000 ALTER TABLE `dbo_modRegistration-Client` DISABLE KEYS */;
LOCK TABLES `dbo_modRegistration-Client` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modRegistration-Client` ENABLE KEYS */;

--
-- Table structure for table `dbo_modRegistration-modRegistration`
--

DROP TABLE IF EXISTS `dbo_modRegistration-modRegistration`;
CREATE TABLE `dbo_modRegistration-modRegistration` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `group` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `class` varchar(50) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `hidden` int(1) NOT NULL default '0',
  `onpage` int(11) NOT NULL default '0',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modRegistration-modRegistration`
--


/*!40000 ALTER TABLE `dbo_modRegistration-modRegistration` DISABLE KEYS */;
LOCK TABLES `dbo_modRegistration-modRegistration` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modRegistration-modRegistration` ENABLE KEYS */;

--
-- Table structure for table `dbo_modSite-Page`
--

DROP TABLE IF EXISTS `dbo_modSite-Page`;
CREATE TABLE `dbo_modSite-Page` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `content` text NOT NULL,
  `name` varchar(100) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `submenu` enum('no','before','after','only') NOT NULL default 'no',
  `onpage` int(11) NOT NULL default '0',
  `hidden` int(1) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modSite-Page`
--


/*!40000 ALTER TABLE `dbo_modSite-Page` DISABLE KEYS */;
LOCK TABLES `dbo_modSite-Page` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modSite-Page` ENABLE KEYS */;

--
-- Table structure for table `dbo_modSite-modSite`
--

DROP TABLE IF EXISTS `dbo_modSite-modSite`;
CREATE TABLE `dbo_modSite-modSite` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `title_index` varchar(255) NOT NULL default '',
  `template` int(11) NOT NULL default '0',
  `content` text NOT NULL,
  `bigname` varchar(255) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `address` varchar(50) NOT NULL default '',
  `onpage` int(11) NOT NULL default '0',
  `hidden` int(1) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modSite-modSite`
--


/*!40000 ALTER TABLE `dbo_modSite-modSite` DISABLE KEYS */;
LOCK TABLES `dbo_modSite-modSite` WRITE;
INSERT INTO `dbo_modSite-modSite` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','',0,0,'',0,'','','Главная','','info@cmsbuilder3','http://cmsbuilder3/',0,0,'');
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modSite-modSite` ENABLE KEYS */;

--
-- Table structure for table `dbo_modTemplates-Dir`
--

DROP TABLE IF EXISTS `dbo_modTemplates-Dir`;
CREATE TABLE `dbo_modTemplates-Dir` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `name` varchar(25) NOT NULL default '',
  `onpage` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modTemplates-Dir`
--


/*!40000 ALTER TABLE `dbo_modTemplates-Dir` DISABLE KEYS */;
LOCK TABLES `dbo_modTemplates-Dir` WRITE;
INSERT INTO `dbo_modTemplates-Dir` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','modTemplates::modTemplates',1,0,'Стандартные',0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modTemplates-Dir` ENABLE KEYS */;

--
-- Table structure for table `dbo_modTemplates-Template`
--

DROP TABLE IF EXISTS `dbo_modTemplates-Template`;
CREATE TABLE `dbo_modTemplates-Template` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `content` text NOT NULL,
  `name` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modTemplates-Template`
--


/*!40000 ALTER TABLE `dbo_modTemplates-Template` DISABLE KEYS */;
LOCK TABLES `dbo_modTemplates-Template` WRITE;
INSERT INTO `dbo_modTemplates-Template` VALUES ('2006-07-08 11:56:09','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','modTemplates::Dir',1,0,'<html>\r\n    <head>\r\n        <title>${site_title}</title>\r\n        <link rel=\"stylesheet\" type=\"text/css\" href=\"/modSite.css\"/>\r\n        <meta name=\"description\" content=\"${site_description}\"/>\r\n    </head>\r\n    <body>\r\n        <table width=\"100%\" border=\"1\">\r\n            <tbody>\r\n                <tr>\r\n                    <td width=\"20%\"></td>\r\n                    <td>${site_navigation}</td>\r\n                </tr>\r\n                <tr>\r\n                    <td valign=\"top\">${modSite::modSite1->site_flatlist}</td>\r\n                    <td valign=\"top\">\r\n                    <h1>${site_head}</h1>\r\n                    ${site_content} ${site_pagesline}</td>\r\n                </tr>\r\n            </tbody>\r\n        </table>\r\n    </body>\r\n</html>','По умолчанию');
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modTemplates-Template` ENABLE KEYS */;

--
-- Table structure for table `dbo_modTemplates-TemplateW`
--

DROP TABLE IF EXISTS `dbo_modTemplates-TemplateW`;
CREATE TABLE `dbo_modTemplates-TemplateW` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `content` text NOT NULL,
  `name` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modTemplates-TemplateW`
--


/*!40000 ALTER TABLE `dbo_modTemplates-TemplateW` DISABLE KEYS */;
LOCK TABLES `dbo_modTemplates-TemplateW` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modTemplates-TemplateW` ENABLE KEYS */;

--
-- Table structure for table `dbo_modTemplates-modTemplates`
--

DROP TABLE IF EXISTS `dbo_modTemplates-modTemplates`;
CREATE TABLE `dbo_modTemplates-modTemplates` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `name` varchar(25) NOT NULL default '',
  `onpage` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modTemplates-modTemplates`
--


/*!40000 ALTER TABLE `dbo_modTemplates-modTemplates` DISABLE KEYS */;
LOCK TABLES `dbo_modTemplates-modTemplates` WRITE;
INSERT INTO `dbo_modTemplates-modTemplates` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','',0,0,'Шаблоны',0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modTemplates-modTemplates` ENABLE KEYS */;

--
-- Table structure for table `dbo_modUsers-Group`
--

DROP TABLE IF EXISTS `dbo_modUsers-Group`;
CREATE TABLE `dbo_modUsers-Group` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `cms` int(1) NOT NULL default '0',
  `html` int(1) NOT NULL default '0',
  `files` int(1) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `root` int(1) NOT NULL default '0',
  `onpage` int(11) NOT NULL default '0',
  `cpanel` int(1) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modUsers-Group`
--


/*!40000 ALTER TABLE `dbo_modUsers-Group` DISABLE KEYS */;
LOCK TABLES `dbo_modUsers-Group` WRITE;
INSERT INTO `dbo_modUsers-Group` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','modUsers::modUsers',1,0,1,1,1,'Администраторы',1,0,1),('2006-07-08 11:45:24','2006-07-08 11:45:24',2,'modUsers::UsermodUsers::User1','modUsers::modUsers',1,0,0,0,0,'Гости',0,0,0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modUsers-Group` ENABLE KEYS */;

--
-- Table structure for table `dbo_modUsers-User`
--

DROP TABLE IF EXISTS `dbo_modUsers-User`;
CREATE TABLE `dbo_modUsers-User` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `email` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `remind` varchar(255) NOT NULL default '',
  `pas` varchar(32) NOT NULL default '',
  `login` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`ID`),
  KEY `login` (`login`),
  KEY `pas` (`pas`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modUsers-User`
--


/*!40000 ALTER TABLE `dbo_modUsers-User` DISABLE KEYS */;
LOCK TABLES `dbo_modUsers-User` WRITE;
INSERT INTO `dbo_modUsers-User` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','modUsers::Group',1,0,'','Администратор','','','admin'),('2006-07-08 11:45:24','2006-07-08 11:45:24',2,'modUsers::UsermodUsers::User1','modUsers::Group',1,0,'','Барменталь','','','barmental'),('2006-07-08 11:45:24','2006-07-08 11:45:24',3,'modUsers::UsermodUsers::User1','modUsers::Group',2,0,'','Гость','','','');
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modUsers-User` ENABLE KEYS */;

--
-- Table structure for table `dbo_modUsers-modUsers`
--

DROP TABLE IF EXISTS `dbo_modUsers-modUsers`;
CREATE TABLE `dbo_modUsers-modUsers` (
  `ATS` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `CTS` timestamp NOT NULL default '0000-00-00 00:00:00',
  `ID` int(11) NOT NULL auto_increment,
  `OWNER` varchar(50) NOT NULL default '0',
  `PAPA_CLASS` varchar(50) NOT NULL default '',
  `PAPA_ID` int(11) NOT NULL default '0',
  `SHCUT` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `onpage` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Dumping data for table `dbo_modUsers-modUsers`
--


/*!40000 ALTER TABLE `dbo_modUsers-modUsers` DISABLE KEYS */;
LOCK TABLES `dbo_modUsers-modUsers` WRITE;
INSERT INTO `dbo_modUsers-modUsers` VALUES ('2006-07-08 11:45:24','2006-07-08 11:45:24',1,'modUsers::UsermodUsers::User1','',0,0,'Пользователи',0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `dbo_modUsers-modUsers` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

